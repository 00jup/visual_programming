from homework import example_02 as ex

ex.solve_square_function(1,10,4)

ex.solve_square_function(1,4,4)
ex.solve_square_function(1,2,3)
